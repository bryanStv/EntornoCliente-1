let cadena = "2+2";

alert("La suma de "+cadena+" es "+eval(cadena));