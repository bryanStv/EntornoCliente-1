var titulo = document.getElementById("t1");
titulo.innerHTML = "EJERCICIO 2";

let formulario = document.getElementById("basicForm");
let resultado = document.getElementById("resultadoEJ2");
let urlWeb = window.location.href;

formulario.addEventListener('submit', function(event){
    event.preventDefault();
    let datoDNI = document.getElementById("dni").value;

    //datoDNI == '' ? alert("No se ha introducido DNI") : resultado.innerHTML = `${datoDNI}`;
    if(datoDNI == ''){
        alert("No se ha introducido DNI");
        document.getElementById("dni").focus();
    }else{
        resultado.innerHTML = `${datoDNI}`;
    }
});