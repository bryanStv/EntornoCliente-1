let n1 = parseInt(prompt("Introduce un número: "));

if(n1%2==0){
    alert("Número Par");
}else{
    alert("Número Impar");
}