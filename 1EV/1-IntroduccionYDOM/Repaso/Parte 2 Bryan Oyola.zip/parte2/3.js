var titulo = document.getElementById("id1");
titulo.innerHTML = "Bienvenido a mi página"+"<br>"+navigator.userAgent;

if(confirm("Quieres continuar?")){
    alert("continuamos...")
}