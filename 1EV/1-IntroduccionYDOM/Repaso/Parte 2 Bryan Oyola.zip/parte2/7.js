function cambioColor(color){
    document.body.style.backgroundColor = color;
}