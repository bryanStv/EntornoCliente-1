function cambioDeVentana(){
    window.open("ej9.html", "_blank", "width=600,height=400");
};

function cambioDeVentana2(){
    //window.open("index.html", "_blank", "width=600,height=400");
    window.close();
}